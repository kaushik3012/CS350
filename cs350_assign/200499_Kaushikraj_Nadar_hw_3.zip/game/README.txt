Requires Gosu to be installed.

 gem install gosu


Afterwards, the game should run with


 ruby game.rb

